-- phpMyAdmin SQL Dump
-- version 4.5.4.1deb2ubuntu2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Aug 03, 2017 at 10:50 PM
-- Server version: 10.0.29-MariaDB-0ubuntu0.16.04.1
-- PHP Version: 7.0.18-0ubuntu0.16.04.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `blog_loc`
--

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `name`) VALUES
(1, 'Texnologiyalar'),
(2, 'Sport'),
(3, 'Jamiyat'),
(4, 'Iqtisodiyot'),
(5, 'Siyosat');

-- --------------------------------------------------------

--
-- Table structure for table `page`
--

CREATE TABLE `page` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `count_view` int(11) NOT NULL,
  `status` enum('active','inactive') NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `page`
--

INSERT INTO `page` (`id`, `title`, `content`, `count_view`, `status`, `created_at`) VALUES
(1, 'Sayt haqida', '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam sagittis lobortis lorem non semper. Proin gravida hendrerit ipsum, ac sollicitudin neque maximus eget. Curabitur viverra lacus et lectus luctus, vitae posuere quam suscipit. Donec facilisis pellentesque interdum. Nulla tristique commodo nulla, eu ultricies arcu. Morbi vel tortor ut massa condimentum mollis ac in lectus. Vestibulum auctor finibus tortor, et bibendum lacus cursus nec. Mauris luctus eleifend neque eu tempor. Pellentesque leo leo, ultricies in facilisis vitae, tristique sit amet erat.</p>\r\n<p>Interdum et malesuada fames ac ante ipsum primis in faucibus. Quisque scelerisque neque vitae neque euismod malesuada. Sed fringilla posuere enim, sodales lacinia sem consequat sed. Curabitur et egestas ante, a mattis nibh. Pellentesque placerat nec neque in mollis. Vivamus non efficitur metus. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Praesent eu neque leo. Nulla sollicitudin enim quis tortor viverra imperdiet eget in magna. Morbi fringilla convallis ligula et rutrum. Curabitur nisl orci, luctus nec quam vitae, interdum convallis eros. Cras sodales orci at tellus elementum, ut vestibulum magna eleifend. Fusce lobortis lacus non dui dapibus, in posuere lorem lobortis.</p>\r\n<p>Curabitur commodo dui semper sollicitudin consectetur. Sed id dictum nunc. Sed sit amet risus in enim volutpat eleifend in eu erat. Nunc elit leo, molestie eget tellus ut, porta consectetur felis. Nulla tincidunt massa non ornare viverra. Proin maximus nisl non justo tincidunt, eu pellentesque lorem iaculis. Pellentesque libero nibh, ornare id odio vel, placerat ullamcorper nulla. Pellentesque eu erat volutpat, faucibus felis dictum, iaculis metus. Nam pharetra iaculis viverra. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Nulla facilisi. In hac habitasse platea dictumst. Vestibulum quis felis sed erat vestibulum efficitur. Praesent et gravida orci.</p>\r\n<p>Donec porta dignissim justo quis eleifend. Curabitur leo turpis, mattis a iaculis eget, dictum sit amet massa. Nullam ut dignissim nisl. Nam feugiat tempor nisi quis finibus. Fusce in cursus lectus, non porttitor nisi. Sed ultrices ligula at varius feugiat. Pellentesque arcu turpis, finibus id felis ac, tristique vehicula risus.</p>\r\n<p>Cras laoreet quam et risus consectetur interdum. Duis vel congue lorem. Cras id massa odio. Suspendisse mollis porttitor pellentesque. Aenean sodales feugiat felis, eu blandit sem tempus ut. Aenean et mi dolor. Quisque eu consectetur purus. Nam lacinia turpis euismod arcu gravida, pharetra venenatis lectus hendrerit. Phasellus volutpat commodo finibus. Ut egestas ipsum erat, non vulputate leo mollis eget. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Nulla elementum urna eu accumsan malesuada. Cras eget sem tortor. Phasellus sed suscipit sem.</p>', 2, 'active', '2017-04-29 14:02:27');

-- --------------------------------------------------------

--
-- Table structure for table `post`
--

CREATE TABLE `post` (
  `id` int(11) NOT NULL,
  `title` text NOT NULL,
  `user_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `description` text NOT NULL,
  `content` longtext NOT NULL,
  `image` varchar(255) NOT NULL,
  `count_view` int(11) NOT NULL,
  `status` enum('active','inactive') NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `post`
--

INSERT INTO `post` (`id`, `title`, `user_id`, `category_id`, `description`, `content`, `image`, `count_view`, `status`, `created_at`) VALUES
(10, '{"uz":"Bir necha OTMda test sinovlari bekor qilinadi.","ru":"Открытая, доброжелательная и прагматичная политика sdfsdf sdf dsf","en":"Памперс 25.07 - 01.08UNICEF statement on the speech of the President of the Republic of Uzbekistan on crime prevention amongst children and youth"}', 1, 1, '{"uz":"Keyingi yildan san`at va ijod bilan bog\'liq yo\'nalishlardagi oliygohlarga kirish imtihonlarida test sinovlari o\'tkazilmaydi.","ru":"Открытая, доброжелательная и прагматичная политика является конечной целью инициативы Узбекистана по формированию атмосферы добрососедства и созданию пояса благополучия","en":"TASHKENT, 15 February 2017 — UNICEF appreciates the attentionof the President of Uzbekistan on crime prevention measures for childrenand youth at a recent meeting with the representatives of Ministry of Interior. "}', '{"uz":"<p>Keyingi yildan san`at va ijod bilan bog\'liq yo\'nalishlardagi oliygohlarga kirish imtihonlarida test sinovlari o\'tkazilmaydi. Bu haqda O\'zbekiston Prezidenti Shavkat Mirziyoyev 3 avgust kuni mamlakat ijodkor ziyolilari vakillari bilan uchrashuvida ma`lum qilgan.<\\/p>\\r\\n<p>Videoselektorda qatnashgan Kun.uz muxbirining xabar berishicha, prezident bunday oliygohlarda faqat ijodiy imtihon bo\'lishini ma`lum qilgan. Bundan maqsad haqiqiy iqtidorlilar qolib, testda ona-tili yoki matematika fani savollarini yechib o\'qishga kirish holatlari oldini olish hisoblanadi.<\\/p>\\r\\n<p>&laquo;O\'zbekiston davlat konservatoriyasi, Madaniyat instituti va Dizayn institutida kirish imtihonlarida test topshirish - xiyonat. Ular qo\'shiq aytishni bilsa, chizishni bilsa, talanti bo\'lsa, iqtidori bo\'lsa, test topshirishlariga yo\'l qo\'ymaslik kerak&raquo;, &mdash; degan prezident.<\\/p>","ru":"<p>Узбекистан, отличаясь самой большой в Центральной Азии численностью населения, богатыми природными ресурсами и удобным географиче&shy;ским расположением, играет ключевую роль в ее социально-экономическом развитии. Поэтому проводимая нашим государством внешняя политика, его отношения с соседними странами имеют важное значение в судь&shy;бе всего региона почти с 70-миллионным населением. В этом же кроется и причина того, что сегодня международные эксперты, мировые средства массовой информации обращают пристальное внимание на внешнюю политику Президента Шавката Мирзиёева с соседними государствами.<\\/p>\\r\\n<p>В выступлении на совместном заседании палат парламента 8 сентября прошлого года глава государства особо подчеркнул, что главным приоритетом внешнеполитиче&shy;ской деятельно&shy;сти Узбекистана является регион Центральной Азии, с&nbsp;ко&shy;торым связаны национальные интересы нашей страны. Мы&nbsp;неизменно остаемся приверженными проведению открытой, доброжелательной и прагматичной политики в&nbsp;отношении своих ближайших соседей&nbsp;&mdash; Туркменистана, Казахстана, Кыргызстана, Таджикистана, сказал Шавкат Мирзиёев.<\\/p>","en":"<p>As a State Party to the Convention on the Rights of the Child, Uzbekistan is undertaking judicial reforms to ensure that the rehabilitative and re-integration aims of the juvenile justice system are in the best interests of the child. The Committee on the Rights of the Child emphasizes dealing with the social roots of offending.It proposes comprehensive prevention programmes at every level of government, and at the community level.<\\/p>"}', 'parsley-261039_960_720.jpg', 1, 'active', '2017-08-03 16:45:10'),
(11, '{"uz":"Ватан. “Қашқирлар макони” катта экранларга қайтмоқда (видео)","ru":"","en":""}', 1, 1, '{"uz":"Туркия телеижодкорлари томонидан бир неча йиллар давомида суратга олиб келинаётган \\"Қашқирлар макони” (Kurtlar Vadisi) сериалининг давоми ҳақида янги маълумотлар пайдо бўлди.","ru":"","en":""}', '{"uz":"<p>Туркия телеижодкорлари томонидан бир неча йиллар давомида суратга олиб келинаётган \\"Қашқирлар макони&rdquo; (Kurtlar Vadisi) сериалининг давоми ҳақида янги маълумотлар пайдо бўлди. Лойиҳанинг янги қисмлари ўтган йили Туркияда амалга ошмай қолган давлат тўнтариши воқеаларига бағишланади. Бу сафар ҳам бош ролни актёр Нажоти Шошмаз маромига етказиб ижро этган бўлиб, фильм воқеалари унинг атрофида юз беради.<\\/p>\\r\\n<p>\\"Қашқирлар макони. Ватан\\" фильмининг илк намойиши 29 сентябрда бўлиб ўтиши кутилмоқда. Шу пайтгача фильмнинг тизер лавҳалари тақдим қилинмоқда. Лойиҳа муаллифларидан бирининг айтишича, лойиҳанинг келгуси қисмлари 2018 йилнинг илк кунларидан намойиш этилади ва бу \\"Қашқирлар маконида тартибсизликлар\\" номи билан экранларга қайтади.<\\/p>\\r\\n<p><iframe src=\\"http:\\/\\/www.youtube.com\\/embed\\/npbfyLAofbw\\" width=\\"640\\" height=\\"360\\" frameborder=\\"0\\" allowfullscreen=\\"allowfullscreen\\" data-mce-fragment=\\"1\\"><\\/iframe><\\/p>\\r\\n<p>&nbsp;<\\/p>","ru":"","en":""}', 'maxresdefault.jpg', 5, 'active', '2017-08-03 17:30:34');

-- --------------------------------------------------------

--
-- Table structure for table `tag`
--

CREATE TABLE `tag` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tag`
--

INSERT INTO `tag` (`id`, `name`) VALUES
(1, 'O\'zbekiston'),
(2, 'Armiya'),
(3, 'Odil Ahmedov');

-- --------------------------------------------------------

--
-- Table structure for table `tag_assign`
--

CREATE TABLE `tag_assign` (
  `id` int(11) NOT NULL,
  `tag_id` int(11) NOT NULL,
  `post_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `full_name` varchar(255) NOT NULL,
  `status` enum('active','inactive') NOT NULL,
  `role` enum('admin','user') NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `password`, `full_name`, `status`, `role`, `created_at`) VALUES
(1, 'admin', '$2y$13$pGNcRvHGeMvUFFHy1PDOy.yunXNI6y1sOBzVVSXXhydoccZIXumJy', 'Amir Temur', 'active', 'admin', '2017-04-29 13:19:08');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `page`
--
ALTER TABLE `page`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `post`
--
ALTER TABLE `post`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_post_user_idx` (`user_id`),
  ADD KEY `fk_post_category1_idx` (`category_id`);

--
-- Indexes for table `tag`
--
ALTER TABLE `tag`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tag_assign`
--
ALTER TABLE `tag_assign`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_tag_assign_post1_idx` (`post_id`),
  ADD KEY `fk_tag_assign_tag1_idx` (`tag_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `page`
--
ALTER TABLE `page`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `post`
--
ALTER TABLE `post`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `tag`
--
ALTER TABLE `tag`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `tag_assign`
--
ALTER TABLE `tag_assign`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `post`
--
ALTER TABLE `post`
  ADD CONSTRAINT `fk_post_category1` FOREIGN KEY (`category_id`) REFERENCES `category` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_post_user` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `tag_assign`
--
ALTER TABLE `tag_assign`
  ADD CONSTRAINT `fk_tag_assign_post1` FOREIGN KEY (`post_id`) REFERENCES `post` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_tag_assign_tag1` FOREIGN KEY (`tag_id`) REFERENCES `tag` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
